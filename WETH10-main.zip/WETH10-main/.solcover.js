module.exports = {
  skipFiles: ['Migrations.sol'],
}
